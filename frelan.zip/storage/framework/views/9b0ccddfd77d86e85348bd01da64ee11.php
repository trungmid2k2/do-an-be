<?php echo e($slot); ?>

<?php /**PATH D:\tool\laragon\www\backend\breeze\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>